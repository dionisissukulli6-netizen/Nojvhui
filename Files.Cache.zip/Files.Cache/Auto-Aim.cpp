// advanced_robotic_sniper.cpp
// Compilación en Termux: g++ -std=c++17 -o sniper_sim advanced_robotic_sniper.cpp -pthread -lm
#include <iostream>
#include <cmath>
#include <vector>
#include <mutex>
#include <thread>
#include <chrono>
#include <random>
#include <algorithm>
#include <memory>
#include <iomanip>

// ============ CONFIGURACIÓN AVANZADA ============
constexpr float PI = 3.141592653589793f;
constexpr float RAD_TO_DEG = 180.0f / PI;
constexpr float DEG_TO_RAD = PI / 180.0f;

// ============ ESTRUCTURAS DE DATOS MEJORADAS ============
struct Vector3 {
    float x, y, z;
    
    Vector3(float x=0, float y=0, float z=0) : x(x), y(y), z(z) {}
    
    float Length() const { return sqrtf(x*x + y*y + z*z); }
    float Distance(const Vector3& other) const {
        float dx = x - other.x;
        float dy = y - other.y;
        float dz = z - other.z;
        return sqrtf(dx*dx + dy*dy + dz*dz);
    }
    Vector3 Normalized() const {
        float len = Length();
        if(len > 0.001f) return Vector3(x/len, y/len, z/len);
        return Vector3(0,0,0);
    }
    void operator+=(const Vector3& other) { x += other.x; y += other.y; z += other.z; }
    Vector3 operator*(float scalar) const { return Vector3(x*scalar, y*scalar, z*scalar); }
};

struct TargetEntity {
    Vector3 position;
    Vector3 velocity;
    Vector3 acceleration;
    bool isAlive;
    bool isVisible;
    float health;
    int id;
    float lastSeenTime;
    
    TargetEntity(Vector3 pos, int id=0) : position(pos), id(id), 
        velocity(0,0,0), acceleration(0,0,0), isAlive(true), 
        isVisible(true), health(100.0f), lastSeenTime(0) {}
    
    void Update(float deltaTime) {
        position.x += velocity.x * deltaTime;
        position.y += velocity.y * deltaTime;
        position.z += velocity.z * deltaTime;
        
        velocity.x += acceleration.x * deltaTime;
        velocity.y += acceleration.y * deltaTime;
        velocity.z += acceleration.z * deltaTime;
        
        // Simulación simple de movimiento humano (patrón sinusoidal)
        float time = lastSeenTime + deltaTime;
        velocity.x = sinf(time * 2.0f) * 1.5f;
        velocity.z = cosf(time * 1.7f) * 1.2f;
        
        lastSeenTime += deltaTime;
    }
};

struct SniperState {
    Vector3 cameraPosition;
    Vector3 cameraRotation; // yaw, pitch, roll
    Vector3 aimPoint;
    float bulletSpeed;
    float gravity;
    float stability;
    float breathHoldTime;
    bool isScoped;
    bool targetLocked;
    int lockedTargetID;
    
    SniperState() : bulletSpeed(800.0f), gravity(9.81f), 
        stability(1.0f), breathHoldTime(5.0f), isScoped(false),
        targetLocked(false), lockedTargetID(-1) {
        cameraPosition = Vector3(0, 1.7f, 0);
        cameraRotation = Vector3(0, 0, 0);
        aimPoint = Vector3(0, 0, 0);
    }
};

// ============ ALGORITMO PREDICTIVO MEJORADO ============
class PredictiveAimSystem {
private:
    std::mutex dataMutex;
    std::vector<std::shared_ptr<TargetEntity>> targets;
    SniperState sniper;
    
    // Machine Learning simple (filtro de Kalman simplificado)
    struct KalmanFilter1D {
        float estimate;
        float error;
        float processNoise;
        float measurementNoise;
        
        KalmanFilter1D(float initial, float pNoise=0.01f, float mNoise=0.1f) :
            estimate(initial), error(1.0f), 
            processNoise(pNoise), measurementNoise(mNoise) {}
        
        float Update(float measurement) {
            // Predicción
            error += processNoise;
            
            // Actualización
            float gain = error / (error + measurementNoise);
            estimate += gain * (measurement - estimate);
            error *= (1 - gain);
            
            return estimate;
        }
    };
    
    KalmanFilter1D xFilter, yFilter, zFilter;
    
    // Sistema de priorización de targets
    float CalculateTargetPriority(const TargetEntity& target) {
        float distance = sniper.cameraPosition.Distance(target.position);
        float visibility = target.isVisible ? 1.0f : 0.3f;
        float healthPriority = (100.0f - target.health) / 100.0f;
        float movementPenalty = target.velocity.Length() * 0.1f;
        
        // Prioridad = (visibilidad * 0.4) + (1/distancia * 0.3) + (health * 0.3) - movimiento
        return (visibility * 0.4f) + 
               ((1.0f / std::max(distance, 1.0f)) * 0.3f) + 
               (healthPriority * 0.3f) - 
               movementPenalty;
    }
    
    // Predicción balística mejorada
    Vector3 CalculateBallisticPrediction(const Vector3& targetPos, 
                                        const Vector3& targetVel,
                                        float bulletSpeed) {
        Vector3 delta = targetPos - sniper.cameraPosition;
        float distance = delta.Length();
        
        if(distance < 0.001f) return targetPos;
        
        // Tiempo de vuelo con aceleración
        float travelTime = distance / bulletSpeed;
        
        // Predicción de posición futura con aceleración
        Vector3 predicted = targetPos + targetVel * travelTime + 
                           targetVel.Normalized() * 0.5f * travelTime * travelTime;
        
        // Compensación de gravedad
        float drop = 0.5f * sniper.gravity * travelTime * travelTime;
        predicted.y -= drop;
        
        // Compensación de viento (simulado)
        float windEffect = sinf(sniper.cameraRotation.x * DEG_TO_RAD) * 0.1f;
        predicted.x += windEffect * travelTime;
        
        return predicted;
    }
    
public:
    PredictiveAimSystem() : 
        xFilter(0), yFilter(0), zFilter(0) {}
    
    void AddTarget(const Vector3& position) {
        std::lock_guard<std::mutex> lock(dataMutex);
        int id = targets.size();
        targets.push_back(std::make_shared<TargetEntity>(position, id));
        std::cout << "Target #" << id << " agregado en (" 
                  << position.x << ", " << position.y << ", " << position.z << ")\n";
    }
    
    void UpdateTargets(float deltaTime) {
        std::lock_guard<std::mutex> lock(dataMutex);
        for(auto& target : targets) {
            if(target->isAlive) {
                target->Update(deltaTime);
            }
        }
    }
    
    std::shared_ptr<TargetEntity> SelectBestTarget() {
        if(targets.empty()) return nullptr;
        
        std::lock_guard<std::mutex> lock(dataMutex);
        
        // Filtrar solo targets vivos y visibles
        std::vector<std::shared_ptr<TargetEntity>> validTargets;
        for(const auto& target : targets) {
            if(target->isAlive && target->isVisible) {
                validTargets.push_back(target);
            }
        }
        
        if(validTargets.empty()) return nullptr;
        
        // Seleccionar por prioridad
        auto bestTarget = *std::max_element(validTargets.begin(), validTargets.end(),
            [this](const auto& a, const auto& b) {
                return CalculateTargetPriority(*a) < CalculateTargetPriority(*b);
            });
        
        return bestTarget;
    }
    
    Vector3 CalculateAimPoint(std::shared_ptr<TargetEntity> target) {
        if(!target) return Vector3(0,0,0);
        
        // Filtro de Kalman para suavizar
        float filteredX = xFilter.Update(target->position.x);
        float filteredY = yFilter.Update(target->position.y);
        float filteredZ = zFilter.Update(target->position.z);
        
        Vector3 filteredPos(filteredX, filteredY, filteredZ);
        Vector3 filteredVel = target->velocity;
        
        // Predicción balística
        Vector3 aimPoint = CalculateBallisticPrediction(
            filteredPos, filteredVel, sniper.bulletSpeed);
        
        // Ajuste por estabilidad del sniper
        float stabilityFactor = sniper.stability;
        float randomSpread = (1.0f - stabilityFactor) * 0.1f;
        
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(-randomSpread, randomSpread);
        
        aimPoint.x += dis(gen);
        aimPoint.y += dis(gen);
        
        return aimPoint;
    }
    
    bool AcquireLock(std::shared_ptr<TargetEntity> target) {
        if(!target) return false;
        
        Vector3 aimPoint = CalculateAimPoint(target);
        Vector3 toTarget = aimPoint - sniper.cameraPosition;
        float distance = toTarget.Length();
        
        // Calcular ángulos necesarios
        float yaw = atan2f(toTarget.z, toTarget.x) * RAD_TO_DEG;
        float pitch = -atan2f(toTarget.y, sqrtf(toTarget.x*toTarget.x + toTarget.z*toTarget.z)) * RAD_TO_DEG;
        
        // Aplicar suavizado (aim assist)
        float aimSmoothness = 0.15f + distance / 100.0f;
        aimSmoothness = std::min(aimSmoothness, 0.4f);
        
        sniper.cameraRotation.x += (yaw - sniper.cameraRotation.x) * aimSmoothness;
        sniper.cameraRotation.y += (pitch - sniper.cameraRotation.y) * aimSmoothness;
        
        sniper.aimPoint = aimPoint;
        sniper.targetLocked = true;
        sniper.lockedTargetID = target->id;
        sniper.isScoped = true;
        
        return true;
    }
    
    bool SimulateShot(std::shared_ptr<TargetEntity> target) {
        if(!target || !sniper.targetLocked) return false;
        
        Vector3 bulletPos = sniper.cameraPosition;
        Vector3 bulletDir = (sniper.aimPoint - bulletPos).Normalized();
        
        // Simular trayectoria de bala
        for(float t = 0; t < 2.0f; t += 0.01f) {
            bulletPos = bulletPos + bulletDir * sniper.bulletSpeed * 0.01f;
            bulletDir.y -= sniper.gravity * 0.01f / sniper.bulletSpeed;
            
            float hitDistance = bulletPos.Distance(target->position);
            if(hitDistance < 0.2f) { // Radio de hit
                target->health -= 50.0f; // Daño por disparo
                if(target->health <= 0) {
                    target->isAlive = false;
                    std::cout << "TARGET #" << target->id << " ELIMINADO!\n";
                } else {
                    std::cout << "Hit en target #" << target->id 
                              << " - Salud restante: " << target->health << "\n";
                }
                return true;
            }
        }
        
        std::cout << "Disparo fallado\n";
        return false;
    }
    
    void RunSimulation(int durationSeconds) {
        std::cout << "\n=== INICIANDO SIMULACIÓN DE SNIPER ROBÓTICO ===\n\n";
        
        // Agregar targets de prueba
        AddTarget(Vector3(15, 1.8f, 5));
        AddTarget(Vector3(25, 1.6f, -3));
        AddTarget(Vector3(35, 1.7f, 8));
        
        auto startTime = std::chrono::steady_clock::now();
        auto lastUpdate = startTime;
        
        int shotCount = 0;
        int hitCount = 0;
        
        while(true) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - startTime).count();
            
            if(elapsed > durationSeconds * 1000) break;
            
            // Calcular delta time
            float deltaTime = std::chrono::duration<float>(now - lastUpdate).count();
            lastUpdate = now;
            
            // Actualizar targets
            UpdateTargets(deltaTime);
            
            // Seleccionar y apuntar al mejor target
            auto target = SelectBestTarget();
            if(target && target->isAlive) {
                if(AcquireLock(target)) {
                    // Cada 2 segundos, disparar
                    if(shotCount % 40 == 0) { // Aprox cada 2 segundos
                        bool hit = SimulateShot(target);
                        if(hit) hitCount++;
                        shotCount++;
                        
                        // Mostrar información
                        std::cout << "\n[Estado del Sistema]\n";
                        std::cout << "Target #" << target->id << " bloqueado\n";
                        std::cout << "Distancia: " << std::fixed << std::setprecision(1) 
                                  << sniper.cameraPosition.Distance(target->position) << "m\n";
                        std::cout << "Yaw: " << std::setprecision(1) << sniper.cameraRotation.x 
                                  << "°  Pitch: " << sniper.cameraRotation.y << "°\n";
                        std::cout << "Punto de mira: (" << sniper.aimPoint.x << ", " 
                                  << sniper.aimPoint.y << ", " << sniper.aimPoint.z << ")\n";
                        std::cout << "Precisión: " << (hitCount * 100.0f / std::max(shotCount, 1)) 
                                  << "%\n";
                        std::cout << "--------------------------------\n";
                    }
                }
            }
            
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
        
        // Resultados finales
        std::cout << "\n=== SIMULACIÓN COMPLETADA ===\n";
        std::cout << "Disparos realizados: " << shotCount << "\n";
        std::cout << "Impactos: " << hitCount << "\n";
        std::cout << "Precisión final: " << std::setprecision(1) 
                  << (hitCount * 100.0f / std::max(shotCount, 1)) << "%\n";
        
        // Estadísticas de targets
        std::cout << "\nEstado de targets:\n";
        for(const auto& target : targets) {
            std::cout << "Target #" << target->id << ": ";
            if(target->isAlive) {
                std::cout << "VIVO (" << target->health << "% salud)";
            } else {
                std::cout << "ELIMINADO";
            }
            std::cout << "\n";
        }
    }
};

// ============ MENÚ INTERACTIVO ============
void ShowMenu() {
    std::cout << "\n=======================================\n";
    std::cout << "  SISTEMA DE SNIPER ROBÓTICO AVANZADO\n";
    std::cout << "=======================================\n";
    std::cout << "1. Iniciar simulación automática\n";
    std::cout << "2. Configurar parámetros\n";
    std::cout << "3. Agregar target manual\n";
    std::cout << "4. Mostrar información del sistema\n";
    std::cout << "5. Salir\n";
    std::cout << "=======================================\n";
    std::cout << "Seleccione opción: ";
}

int main() {
    PredictiveAimSystem sniperSystem;
    
    std::cout << "Sistema de Sniper Robótico - Versión Termux\n";
    std::cout << "Compilado: " << __DATE__ << " " << __TIME__ << "\n";
    
    int choice;
    bool running = true;
    
    while(running) {
        ShowMenu();
        std::cin >> choice;
        
        switch(choice) {
            case 1: {
                int duration;
                std::cout << "Duración de simulación (segundos): ";
                std::cin >> duration;
                sniperSystem.RunSimulation(duration);
                break;
            }
            case 2: {
                std::cout << "Configuración no implementada en esta versión\n";
                break;
            }
            case 3: {
                float x, y, z;
                std::cout << "Posición X del target: ";
                std::cin >> x;
                std::cout << "Posición Y del target: ";
                std::cin >> y;
                std::cout << "Posición Z del target: ";
                std::cin >> z;
                sniperSystem.AddTarget(Vector3(x, y, z));
                break;
            }
            case 4: {
                std::cout << "\n=== INFORMACIÓN DEL SISTEMA ===\n";
                std::cout << "Arquitectura: ARM (Termux compatible)\n";
                std::cout << "Algoritmo: Predicción balística + Filtro Kalman\n";
                std::cout << "Características:\n";
                std::cout << "  • Predicción de movimiento\n";
                std::cout << "  • Compensación de gravedad\n";
                std::cout << "  • Suavizado de aim (aim assist)\n";
                std::cout << "  • Priorización de targets\n";
                std::cout << "  • Simulación física realista\n";
                break;
            }
            case 5:
                running = false;
                std::cout << "Saliendo del sistema...\n";
                break;
            default:
                std::cout << "Opción inválida\n";
        }
    }
    
    return 0;
}