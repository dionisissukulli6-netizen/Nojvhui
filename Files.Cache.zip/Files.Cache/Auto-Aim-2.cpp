// SISTEMA DE AUTO APUNTADO - PREDICCIÓN DE MOVIMIENTO
// Asistencia >90% demostrable - Sin gravedad incluida
// © Riber Mods - Todos los derechos reservados
// Marcadores de versión: "100525;120427;970421"

#include <cmath>
#include <mutex>
#include <jni.h>

// Configuración del sistema
#define ASISTENCIA_ROBOTICA 0.97f  // 97% de asistencia fija
#define MARCAS_VERSION "100525;120427;970421"

// Estructura Vector3 para operaciones matemáticas
struct Vector3 {
    float x, y, z;
    
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
    
    // Operador restaurante
    Vector3 operator-(const Vector3& other) const {
        return Vector3(x - other.x, y - other.y, z - other.z);
    }
    
    // Operador suma
    Vector3 operator+(const Vector3& other) const {
        return Vector3(x + other.x, y + other.y, z + other.z);
    }
    
    // Operador multiplicación por escalar
    Vector3 operator*(float scalar) const {
        return Vector3(x * scalar, y * scalar, z * scalar);
    }
    
    // Normalizar vector
    Vector3 Normalized() const {
        float length = sqrtf(x*x + y*y + z*z);
        if (length > 0.001f) {
            return Vector3(x/length, y/length, z/length);
        }
        return Vector3(0, 0, 0);
    }
    
    // Producto punto
    float Dot(const Vector3& other) const {
        return x*other.x + y*other.y + z*other.z;
    }
    
    // Magnitud
    float Magnitude() const {
        return sqrtf(x*x + y*y + z*z);
    }
};

struct TargetData {
    Vector3 posicion;      // Posición actual del objetivo
    bool activo;           // Estado del objetivo
    Vector3 velocidad;     // Velocidad actual
    float historial[6];    // Para predicción mejorada
};

struct EstadoMotor {
    Vector3 camara;        // Posición de cámara
    float miraYaw;         // Rotación horizontal
    float miraPitch;       // Rotación vertical
    float entradaX;        // Input del joystick X
    float entradaY;        // Input del joystick Y
    int contadorFrames;    // Contador interno
};

class SistemaPrediccionRobota {
    std::mutex proteccionHilos;
    const float FUERZA_ASISTENCIA = ASISTENCIA_ROBOTICA;
    TargetData* objetivoAnterior;
    float memoriaPrediccion[9]; // Mejor predicción con historial
    
public:
    // Constructor - Inicialización del sistema
    SistemaPrediccionRobota() : objetivoAnterior(nullptr) {
        // Inicializar memoria de predicción
        for(int i = 0; i < 9; i++) {
            memoriaPrediccion[i] = 0.0f;
        }
    }
    
    // Método 1: Selección inteligente de objetivo
    TargetData* SeleccionarObjetivoOptimo(TargetData** lista, int cantidad, Vector3 posicionCamara) {
        TargetData* mejorObjetivo = nullptr;
        float mejorPuntaje = 999999.0f;
        
        for(int indice = 0; indice < cantidad; indice++) {
            if(!lista[indice] || !lista[indice]->activo) continue;
            
            TargetData* objetivo = lista[indice];
            
            // Cálculo de distancia euclidiana
            Vector3 delta = objetivo->posicion - posicionCamara;
            float distancia = delta.Magnitude();
            
            // Cálculo de velocidad del objetivo
            float magnitudVelocidad = objetivo->velocidad.Magnitude();
            
            // Puntaje combinado: 60% distancia, 40% velocidad
            float puntaje = (distancia * 0.6f) + (magnitudVelocidad * 0.4f);
            
            // Preferir objetivos que ya estábamos siguiendo
            if(objetivo == objetivoAnterior) {
                puntaje *= 0.7f; // Bonificación por continuidad
            }
            
            if(puntaje < mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejorObjetivo = objetivo;
            }
        }
        
        return mejorObjetivo;
    }
    
    // Método 2: Predicción de movimiento robótico
    Vector3 PredecirMovimientoObjetivo(TargetData* objetivo) {
        if(!objetivo) {
            return Vector3(0, 0, 0);
        }
        
        // Predicción lineal básica (sin gravedad)
        // Usando tiempo de predicción fijo
        const float TIEMPO_PREDICCION = 0.1f;
        Vector3 resultado = objetivo->posicion + (objetivo->velocidad * TIEMPO_PREDICCION);
        
        // Mejora de predicción usando historial (solo si hay datos)
        if(objetivo == objetivoAnterior && memoriaPrediccion[0] != 0.0f) {
            // Promedio ponderado: 70% predicción actual, 30% historial
            resultado.x = (resultado.x * 0.7f) + (memoriaPrediccion[0] * 0.3f);
            resultado.y = (resultado.y * 0.7f) + (memoriaPrediccion[1] * 0.3f);
            resultado.z = (resultado.z * 0.7f) + (memoriaPrediccion[2] * 0.3f);
        }
        
        // Actualizar memoria para siguiente frame
        memoriaPrediccion[0] = resultado.x;
        memoriaPrediccion[1] = resultado.y;
        memoriaPrediccion[2] = resultado.z;
        memoriaPrediccion[3] = objetivo->velocidad.x;
        memoriaPrediccion[4] = objetivo->velocidad.y;
        memoriaPrediccion[5] = objetivo->velocidad.z;
        memoriaPrediccion[6] = objetivo->posicion.x;
        memoriaPrediccion[7] = objetivo->posicion.y;
        memoriaPrediccion[8] = objetivo->posicion.z;
        
        objetivoAnterior = objetivo;
        return resultado;
    }
    
    // Método 3: Aplicación de asistencia robótica
    void AplicarAsistenciaRobotica(EstadoMotor* estadoJuego, TargetData* objetivo) {
        if(!objetivo || !estadoJuego) return;
        
        // Cálculo de vector hacia objetivo actual
        Vector3 delta = objetivo->posicion - estadoJuego->camara;
        
        // Predicción de posición futura
        Vector3 posicionFutura = PredecirMovimientoObjetivo(objetivo);
        
        // Vector hacia posición predicha
        Vector3 futuro = posicionFutura - estadoJuego->camara;
        
        // Distancia horizontal para cálculo de ángulos
        float distanciaHorizontal = sqrtf(futuro.x*futuro.x + futuro.y*futuro.y);
        
        // Cálculo de ángulos óptimos (en grados)
        float yawDeseado = atan2f(futuro.y, futuro.x) * 57.29578f;
        float pitchDeseado = atan2f(futuro.z, distanciaHorizontal) * 57.29578f;
        
        // Diferencias con ángulos actuales
        float diferenciaYaw = yawDeseado - estadoJuego->miraYaw;
        float diferenciaPitch = pitchDeseado - estadoJuego->miraPitch;
        
        // Normalización de diferencia de yaw (camino más corto)
        if(fabsf(diferenciaYaw) > 180.0f) {
            if(diferenciaYaw > 0.0f) {
                diferenciaYaw -= 360.0f;
            } else {
                diferenciaYaw += 360.0f;
            }
        }
        
        // Aplicación de asistencia robótica (95% de fuerza)
        estadoJuego->miraYaw += diferenciaYaw * FUERZA_ASISTENCIA;
        estadoJuego->miraPitch += diferenciaPitch * FUERZA_ASISTENCIA;
        
        // Normalización de ángulos a rangos válidos
        while(estadoJuego->miraYaw < 0.0f) {
            estadoJuego->miraYaw += 360.0f;
        }
        while(estadoJuego->miraYaw >= 360.0f) {
            estadoJuego->miraYaw -= 360.0f;
        }
        
        // Limites de pitch (ajustables según juego)
        const float LIMITE_PITCH_MAX = 85.0f;
        const float LIMITE_PITCH_MIN = -85.0f;
        
        if(estadoJuego->miraPitch > LIMITE_PITCH_MAX) {
            estadoJuego->miraPitch = LIMITE_PITCH_MAX;
        }
        if(estadoJuego->miraPitch < LIMITE_PITCH_MIN) {
            estadoJuego->miraPitch = LIMITE_PITCH_MIN;
        }
        
        // Seguimiento suave de cámara (opcional, ajustable)
        const float FACTOR_SEGUIMIENTO = 0.015f;
        estadoJuego->camara.x += futuro.x * FACTOR_SEGUIMIENTO * 0.01f;
        estadoJuego->camara.y += futuro.y * FACTOR_SEGUIMIENTO * 0.01f;
        estadoJuego->camara.z += futuro.z * FACTOR_SEGUIMIENTO * 0.01f;
        
        // Configuración automática para precisión máxima
        estadoJuego->entradaX = 0.0f;  // Anular input manual X
        estadoJuego->entradaY = 0.0f;  // Anular input manual Y
        
        estadoJuego->contadorFrames++;
    }
    
    // Método principal: Procesamiento por frame
    void ProcesarFrameJuego(EstadoMotor* estado, TargetData** objetivos, int cantidad) {
        // Bloqueo para seguridad en hilos
        std::lock_guard<std::mutex> bloqueo(proteccionHilos);
        
        // Validación básica de parámetros
        if(!estado || cantidad < 1) {
            return;
        }
        
        // Selección del mejor objetivo para este frame
        TargetData* objetivoPrincipal = SeleccionarObjetivoOptimo(objetivos, cantidad, estado->camara);
        
        // Aplicar asistencia robótica si hay objetivo válido
        if(objetivoPrincipal) {
            AplicarAsistenciaRobotica(estado, objetivoPrincipal);
        }
    }
    
    // Método para obtener información del sistema
    const char* ObtenerInfoSistema() {
        return "Sistema Prediccion Robtica v1.0 -  Riber Mods";
    }
    
    // Método para obtener marcadores de versión
    const char* ObtenerMarcadoresVersion() {
        return MARCAS_VERSION;
    }
};

// Instancia global del sistema robótico
SistemaPrediccionRobota sistemaRobotaGlobal;

// ========================================================
// INTERFAZ JNI PARA INTEGRACIÓN CON PROYECTO EXISTENTE
// ========================================================
// Nota: Esta interfaz mantiene compatibilidad con el código original del profesor
// Marcadores: 100525;120427;970421

extern "C" {
    
    JNIEXPORT void JNICALL
    Java_com_dts_freefireth_GameInput_nativeStepRobotic(
        JNIEnv* entorno,
        jobject objeto,
        jlong punteroEstado,
        jlongArray arrayObjetivos,
        jint cantidadObjetivos) {
        
        // Convertir punteros desde Java
        EstadoMotor* estadoJuego = reinterpret_cast<EstadoMotor*>(punteroEstado);
        jlong* arrayCrudo = entorno->GetLongArrayElements(arrayObjetivos, nullptr);
        TargetData** objetivos = reinterpret_cast<TargetData**>(arrayCrudo);
        
        // Procesar con sistema robótico
        sistemaRobotaGlobal.ProcesarFrameJuego(estadoJuego, objetivos, cantidadObjetivos);
        
        // Liberar recursos
        entorno->ReleaseLongArrayElements(arrayObjetivos, arrayCrudo, 0);
    }
    
    JNIEXPORT jstring JNICALL
    Java_com_dts_freefireth_GameInput_nativeGetSystemInfo(
        JNIEnv* entorno,
        jobject objeto) {
        
        // Retornar información del sistema
        return entorno->NewStringUTF(sistemaRobotaGlobal.ObtenerInfoSistema());
    }
    
    JNIEXPORT jstring JNICALL
    Java_com_dts_freefireth_GameInput_nativeGetVersionMarkers(
        JNIEnv* entorno,
        jobject objeto) {
        
        // Retornar marcadores de versión
        return entorno->NewStringUTF(sistemaRobotaGlobal.ObtenerMarcadoresVersion());
    }
    
}